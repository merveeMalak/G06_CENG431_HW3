import controller.ResearcherController;
import fileManagement.BibFileManagement;
import fileManagement.CsvFileManagement;


import fileManagement.XmlFileManagement;
import model.Paper;
import model.Researcher;
import view.LoginView;

import javax.swing.*;
import java.util.List;


public class OpenResearcherApp {


    public static void main(String[] args) {
        OpenResearcherSimulation mainApp = new OpenResearcherSimulation();

    }
}