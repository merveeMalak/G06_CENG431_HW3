package fileIO;

import java.util.List;

public interface IReadFileIO<T> {
    T readFile();
}


