package fileIO;

import java.util.List;

public interface IWriteFileIO<T> {

    public void writeFileIO(T lines);
}
