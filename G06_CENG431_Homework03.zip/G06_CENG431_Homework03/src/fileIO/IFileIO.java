package fileIO;

public interface IFileIO<T, H> extends IReadFileIO<H>, IWriteFileIO<T> {

}
