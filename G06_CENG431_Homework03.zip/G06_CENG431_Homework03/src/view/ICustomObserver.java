package view;

public interface ICustomObserver {
    public void update(ICustomSubject subject);
}
